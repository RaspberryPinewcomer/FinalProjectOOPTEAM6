import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import lib.GeometryIO;

class GeoTester {

	@Test
	public void testAreaOfTrianglePass() {
		
		
		
		assertEquals(2, GeometryIO.areaOfTriangle(2, 2), "Pass");
	}
	
	@Test
	public void testAreaOfTriangleFail() {
		
		assertEquals(2, GeometryIO.areaOfTriangle(-2, 2), "Throws");
		assertEquals(2, GeometryIO.areaOfTriangle(2, -2), "Throws");
		assertEquals(2, GeometryIO.areaOfTriangle(0, 2), "Throws");
		assertEquals(2, GeometryIO.areaOfTriangle(2, 0), "Throws");
		
	}

}
